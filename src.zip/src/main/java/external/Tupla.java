public class Tupla <T1, T2>{
	public T1 x;
	public T2 y;

	public Tupla(T1 x, T2 y){
		this.x = x;
		this.y = y;
	}
}